/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2017/7/1 19:05:59                            */
/*==============================================================*/


drop table if exists OrderDetail;

drop table if exists OrderStatus;

drop table if exists ProductionStatus;

drop table if exists address;

drop table if exists admin;

drop table if exists category;

drop table if exists favorite;

drop table if exists gender;

drop table if exists pro2cate;

drop table if exists production;

drop table if exists shopcart;

drop table if exists shopcart_production;

drop table if exists user;

drop table if exists userOrder;

/*==============================================================*/
/* Table: OrderDetail                                           */
/*==============================================================*/
create table OrderDetail
(
   OrderDetail_id       varchar(32) not null,
   userId               varchar(32),
   orderId              varchar(32),
   OrderDetail_Production_id varchar(32) not null,
   OrderDetail_Production_Price float(10,2) not null,
   OrderDetail_Production_Amount int not null,
   primary key (OrderDetail_id)
);

/*==============================================================*/
/* Table: OrderStatus                                           */
/*==============================================================*/
create table OrderStatus
(
   orderstatus_id       int not null,
   orderstatus_desc     varchar(50) not null,
   primary key (orderstatus_id)
);

/*==============================================================*/
/* Table: ProductionStatus                                      */
/*==============================================================*/
create table ProductionStatus
(
   production_status_id int not null,
   production_status_desc varchar(20) not null,
   primary key (production_status_id)
);

/*==============================================================*/
/* Table: address                                               */
/*==============================================================*/
create table address
(
   userId               varchar(32) not null,
   addressId            varchar(32) not null,
   addressStr           varchar(500) not null,
   addressPhone         char(11) not null,
   addressName          varchar(30) not null,
   addressPost          char(6),
   primary key (userId, addressId)
);

/*==============================================================*/
/* Table: admin                                                 */
/*==============================================================*/
create table admin
(
   adminId              varchar(32) not null,
   adminAccount         varchar(30) not null,
   adminPassword        varchar(32) not null,
   adminName            varchar(32) not null,
   primary key (adminId)
);

/*==============================================================*/
/* Table: category                                              */
/*==============================================================*/
create table category
(
   categoryId           varchar(32) not null,
   categoryTitle        varchar(32) not null,
   primary key (categoryId)
);

/*==============================================================*/
/* Table: favorite                                              */
/*==============================================================*/
create table favorite
(
   proId                varchar(32) not null,
   userId               varchar(32) not null,
   favoriteId           varchar(32) not null,
   favoriteDate         date not null,
   primary key (proId, userId, favoriteId)
);

/*==============================================================*/
/* Table: gender                                                */
/*==============================================================*/
create table gender
(
   genderId             int not null,
   userId               varchar(32),
   genderDesc           varchar(10) not null,
   primary key (genderId)
);

/*==============================================================*/
/* Table: pro2cate                                              */
/*==============================================================*/
create table pro2cate
(
   categoryId           varchar(32) not null,
   proId                varchar(32) not null,
   primary key (categoryId, proId)
);

/*==============================================================*/
/* Table: production                                            */
/*==============================================================*/
create table production
(
   proId                varchar(32) not null,
   production_status_id int,
   proBar               varchar(32) not null,
   proName              varchar(32) not null,
   proPrice             numeric(5,2) not null,
   proDscp              varchar(250) not null,
   proDetailDscp        varchar(500),
   proMainPic           varchar(500) not null,
   primary key (proId)
);

/*==============================================================*/
/* Table: shopcart                                              */
/*==============================================================*/
create table shopcart
(
   shopcartId           varchar(32) not null,
   userId               varchar(32),
   production_kind_amount int not null,
   primary key (shopcartId)
);

/*==============================================================*/
/* Table: shopcart_production                                   */
/*==============================================================*/
create table shopcart_production
(
   sp_id                varchar(32) not null,
   shopcartId           varchar(32),
   production_amount    int not null,
   production_id        varchar(32) not null,
   primary key (sp_id)
);

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   userId               varchar(32) not null,
   shopcartId           varchar(32),
   userAccount          varchar(32) not null,
   userName             varchar(32) not null,
   userPassword         varchar(32) not null,
   userMail             varchar(50) not null,
   primary key (userId)
);

/*==============================================================*/
/* Table: userOrder                                             */
/*==============================================================*/
create table userOrder
(
   userId               varchar(32) not null,
   orderId              varchar(32) not null,
   orderstatus_id       int,
   orderDatetime        datetime not null,
   orderCancleDatetime  datetime,
   orderDeliverDatetime datetime,
   orderFinishDatetime  datetime,
   orderTotalPrice      float(10,2) not null,
   primary key (userId, orderId)
);

alter table OrderDetail add constraint FK_Relationship_10 foreign key (userId, orderId)
      references userOrder (userId, orderId) on delete restrict on update restrict;

alter table address add constraint FK_user2address foreign key (userId)
      references user (userId) on delete restrict on update restrict;

alter table favorite add constraint FK_pro2favo foreign key (proId)
      references production (proId) on delete restrict on update restrict;

alter table favorite add constraint FK_user2favo foreign key (userId)
      references user (userId) on delete restrict on update restrict;

alter table gender add constraint FK_Relationship_12 foreign key (userId)
      references user (userId) on delete restrict on update restrict;

alter table pro2cate add constraint FK_pro2cate foreign key (categoryId)
      references category (categoryId) on delete restrict on update restrict;

alter table pro2cate add constraint FK_pro2cate2 foreign key (proId)
      references production (proId) on delete restrict on update restrict;

alter table production add constraint FK_Relationship_11 foreign key (production_status_id)
      references ProductionStatus (production_status_id) on delete restrict on update restrict;

alter table shopcart add constraint FK_Relationship_14 foreign key (userId)
      references user (userId) on delete restrict on update restrict;

alter table shopcart_production add constraint FK_Relationship_7 foreign key (shopcartId)
      references shopcart (shopcartId) on delete restrict on update restrict;

alter table user add constraint FK_Relationship_13 foreign key (shopcartId)
      references shopcart (shopcartId) on delete restrict on update restrict;

alter table userOrder add constraint FK_Relationship_9 foreign key (orderstatus_id)
      references OrderStatus (orderstatus_id) on delete restrict on update restrict;

alter table userOrder add constraint FK_user2order foreign key (userId)
      references user (userId) on delete restrict on update restrict;

